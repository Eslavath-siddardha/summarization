import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

# Load spaCy model
nlp = spacy.load('en_core_web_sm')

def preprocess_text(text):
    # Tokenize text into sentences using spaCy's built-in tokenizer
    doc = nlp(text)
    sentences = [sent.text for sent in doc.sents]
    
    # Remove stopwords and punctuation, and lemmatize using spaCy
    processed_sentences = []
    for sentence in sentences:
        doc = nlp(sentence.lower())  # Convert to lowercase
        tokens = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct]
        processed_sentences.append(' '.join(tokens))
    
    return sentences, processed_sentences

def compute_tfidf_scores(processed_sentences):
    # Apply TF-IDF Vectorizer to compute importance of terms
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(processed_sentences)
    
    # Compute sentence scores based on TF-IDF (sum of TF-IDF values of the words in each sentence)
    scores = np.array(tfidf_matrix.sum(axis=1)).flatten()
    return scores

def get_top_sentences(sentences, scores, top_n=3):
    # Rank sentences based on their scores and select the top N
    ranked_indices = np.argsort(scores)[::-1]  # Sort the indices based on scores
    top_sentences = [sentences[i] for i in ranked_indices[:top_n]]
    return ' '.join(top_sentences)

def extractive_summary(text, top_n=3):
    # Preprocess the text to get the sentences and their processed forms
    sentences, processed_sentences = preprocess_text(text)
    
    # Compute TF-IDF scores for each sentence
    scores = compute_tfidf_scores(processed_sentences)
    
    # Get the top N sentences based on their scores
    summary = get_top_sentences(sentences, scores, top_n)
    
    return summary

# Example document
text = """
Artificial intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think like humans and mimic their actions.
AI can be categorized into two types: narrow AI and general AI.
Narrow AI is specialized in performing a single task, while general AI is capable of performing any intellectual task that a human can.
Machine learning is a subset of AI that allows computers to learn from data without being explicitly programmed.
Deep learning is a subset of machine learning, and it uses neural networks to model complex patterns in data.
AI technologies are already revolutionizing industries like healthcare, finance, and transportation.
"""

# Get extractive summary
summary = extractive_summary(text, top_n=3)
print("Extractive Summary:")
print(summary)
